﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Estudiante
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(25, ErrorMessage = "El nombre no puede tener más de 50 caracteres")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(25, ErrorMessage = "El apellido no puede tener más de 50 caracteres")]
        public string Apellido { get; set; }

        [Required(ErrorMessage = "La edad es obligatoria")]
        [Range(18, 60, ErrorMessage = "La edad debe estar entre 1 y 120")]
        public int Edad { get; set; }

        [Required(ErrorMessage = "El correo electrónico es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de correo electrónico no válido")]
        [StringLength(100, ErrorMessage = "El correo no puede tener más de 100 caracteres")]
        public string? Email { get; set; }

       
    }
}
