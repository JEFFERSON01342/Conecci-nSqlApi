﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewEstudiantes = new DataGridView();
            txt_Nombre = new TextBox();
            txt_Apellido = new TextBox();
            txt_Email = new TextBox();
            txt_Edad = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btn_Agregar = new Button();
            btn_Actualizar = new Button();
            btn_Eliminar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEstudiantes).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewEstudiantes
            // 
            dataGridViewEstudiantes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEstudiantes.Location = new Point(271, 87);
            dataGridViewEstudiantes.Name = "dataGridViewEstudiantes";
            dataGridViewEstudiantes.Size = new Size(371, 241);
            dataGridViewEstudiantes.TabIndex = 0;
            // 
            // txt_Nombre
            // 
            txt_Nombre.Location = new Point(127, 87);
            txt_Nombre.Name = "txt_Nombre";
            txt_Nombre.Size = new Size(102, 23);
            txt_Nombre.TabIndex = 1;
            // 
            // txt_Apellido
            // 
            txt_Apellido.Location = new Point(127, 137);
            txt_Apellido.Name = "txt_Apellido";
            txt_Apellido.Size = new Size(102, 23);
            txt_Apellido.TabIndex = 2;
            // 
            // txt_Email
            // 
            txt_Email.Location = new Point(127, 245);
            txt_Email.Name = "txt_Email";
            txt_Email.Size = new Size(102, 23);
            txt_Email.TabIndex = 4;
            // 
            // txt_Edad
            // 
            txt_Edad.Location = new Point(127, 195);
            txt_Edad.Name = "txt_Edad";
            txt_Edad.Size = new Size(102, 23);
            txt_Edad.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 203);
            label1.Name = "label1";
            label1.Size = new Size(33, 15);
            label1.TabIndex = 5;
            label1.Text = "Edad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 90);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 5;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 145);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 6;
            label3.Text = "Apellido";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 253);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 7;
            label4.Text = "Email";
            // 
            // btn_Agregar
            // 
            btn_Agregar.Location = new Point(154, 305);
            btn_Agregar.Name = "btn_Agregar";
            btn_Agregar.Size = new Size(75, 23);
            btn_Agregar.TabIndex = 8;
            btn_Agregar.Text = "Agregar";
            btn_Agregar.UseVisualStyleBackColor = true;
            btn_Agregar.Click += btn_Agregar_Click;
            // 
            // btn_Actualizar
            // 
            btn_Actualizar.Location = new Point(59, 305);
            btn_Actualizar.Name = "btn_Actualizar";
            btn_Actualizar.Size = new Size(75, 23);
            btn_Actualizar.TabIndex = 9;
            btn_Actualizar.Text = "Actualizar";
            btn_Actualizar.UseVisualStyleBackColor = true;
            btn_Actualizar.Click += btn_Actualizar_Click;
            // 
            // btn_Eliminar
            // 
            btn_Eliminar.Location = new Point(104, 343);
            btn_Eliminar.Name = "btn_Eliminar";
            btn_Eliminar.Size = new Size(75, 23);
            btn_Eliminar.TabIndex = 10;
            btn_Eliminar.Text = "Eliminar";
            btn_Eliminar.UseVisualStyleBackColor = true;
            btn_Eliminar.Click += btn_Eliminar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_Eliminar);
            Controls.Add(btn_Actualizar);
            Controls.Add(btn_Agregar);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txt_Email);
            Controls.Add(txt_Edad);
            Controls.Add(txt_Apellido);
            Controls.Add(txt_Nombre);
            Controls.Add(dataGridViewEstudiantes);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridViewEstudiantes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewEstudiantes;
        private TextBox txt_Nombre;
        private TextBox txt_Apellido;
        private TextBox txt_Email;
        private TextBox txt_Edad;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btn_Agregar;
        private Button btn_Actualizar;
        private Button btn_Eliminar;
    }
}
