using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebApplication1.Models;


namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public string baseUrl = "https://localhost:7018/api/Estudiantes";
        HttpClient cliente = new HttpClient();
        public Form1()
        {
            InitializeComponent();
            CargarDatos();
        }

        private async void CargarDatos()
        {
            var respuesta = await cliente.GetAsync(baseUrl); // instalar newton
            var json = await respuesta.Content.ReadAsStringAsync();
            var estudiantes = JsonSerializer.Deserialize<List<Estudiante>>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }); // crear carpeta models en el nuevo form
            dataGridViewEstudiantes.DataSource = estudiantes;
        }

        private async void btn_Agregar_Click(object sender, EventArgs e)
        {
            var estudiante = new Estudiante()
            {
                Nombre = txt_Nombre.Text,
                Apellido = txt_Apellido.Text,
                Edad = Convert.ToInt32(txt_Edad.Text),
                Email = txt_Email.Text
            };
            var response = await cliente.PostAsJsonAsync(baseUrl, estudiante);
            if (response.IsSuccessStatusCode)
            {
                MessageBox.Show("Agregado Correctamente");
            }
            else
            {
                var error = await response.Content.ReadAsStringAsync();
                MessageBox.Show(error);
            }
            CargarDatos();
        }

        private async void btn_Actualizar_Click(object sender, EventArgs e)
        {
            if (dataGridViewEstudiantes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un estudiante para actualizar");
            }
            else
            {
                var estudiante = (Estudiante)dataGridViewEstudiantes.CurrentRow.DataBoundItem;
                estudiante.Nombre = txt_Nombre.Text;
                estudiante.Apellido = txt_Apellido.Text;
                estudiante.Edad = Convert.ToInt32(txt_Edad.Text);
                estudiante.Email = txt_Email.Text;
                var response = await cliente.PutAsJsonAsync($"{baseUrl}/{estudiante.Id}", estudiante);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Actualizado correctamente");
                    CargarDatos();
                }
                else
                {
                    var error = await response.Content.ReadAsStringAsync();
                    MessageBox.Show(error);
                }
            }
        }

        private async void btn_Eliminar_Click(object sender, EventArgs e)
        {
            if (dataGridViewEstudiantes.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un estudiante para Eliminar");
            }
            else
            {
                var estudiante = (Estudiante)dataGridViewEstudiantes.CurrentRow.DataBoundItem;
                var confirmation = MessageBox.Show("Desea continuar?","Confirmaci�n",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);
                if (confirmation==DialogResult.Yes)
                {
                    var response = await cliente.DeleteAsync($"{baseUrl}/{estudiante.Id}");
                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Eliminado correctamente");
                        CargarDatos();
                    }
                    else
                    {
                        var error = await response.Content.ReadAsStringAsync();
                        MessageBox.Show(error);
                    }
                }
            }
        }
    }
}
 // depurar, nueva instancia
